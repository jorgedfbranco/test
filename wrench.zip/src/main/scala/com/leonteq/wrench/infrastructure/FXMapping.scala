package com.leonteq.wrench.infrastructure

import javafx.collections.ObservableList
import org.fxmisc.easybind.EasyBind

import scala.compat.java8.FunctionConverters._

object FXMapping {
  implicit class RichObservableList[A](val ls: ObservableList[A]) extends AnyVal {
    def map[B <: AnyRef](f: A => B): ObservableList[B] =
      EasyBind.map[A, B](ls, f.asJava)
  }
}