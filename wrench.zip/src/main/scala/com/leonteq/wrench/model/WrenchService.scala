package com.leonteq.wrench.model

case class ServiceId(id: String)
case class ServiceTag(tag: String)
case class EnvironmentId(id: String)

class WrenchService {
  def listServices(): List[ServiceId] =
    List("anna-ui", "anna-server", "instrument-service", "workbench")
      .map(ServiceId.apply)

  def listEnvironments(serviceId: ServiceId): List[EnvironmentId] = {
    val r =
      List("DEV63", "SIT1", "SIT2", "UAT63", "PRE63", "PROD63", "DEMO1", "DEMO2")
        .map(EnvironmentId.apply)
    if (serviceId.id == "anna-ui") r.take(2)
    else if (serviceId.id == "workbench") r.takeRight(4)
    else r
  }

  def listTags(serviceId: ServiceId, environmentId: EnvironmentId): List[ServiceTag] = {
    List()
  }
}