package com.leonteq.wrench

import com.leonteq.wrench.model.WrenchService
import com.leonteq.wrench.ui.{MainView, MainViewModel}
import javafx.application.Application
import javafx.scene.Scene
import javafx.stage.Stage

object Main {
  def main (args: Array[String]): Unit = {
    Application.launch(classOf[Main], args:_*)
  }
}

class Main extends Application {
  implicit val wrenchService = new WrenchService

  override def start(stage: Stage): Unit = {
    stage.setTitle("Wrench")
    stage.setWidth(800)
    stage.setHeight(400)
    stage.setScene(new Scene(new MainView(new MainViewModel)))
    stage.show()
  }
}