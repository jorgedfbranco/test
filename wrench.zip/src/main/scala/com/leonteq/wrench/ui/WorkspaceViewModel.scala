package com.leonteq.wrench.ui

import com.leonteq.wrench.model.{EnvironmentId, ServiceTag, WrenchService}
import javafx.collections.FXCollections

case class WorkspaceViewModel(environment: EnvironmentId)(implicit wrenchService: WrenchService) {
  private val _availableTags = FXCollections.observableArrayList[ServiceTag]()

  val availableTags = FXCollections.checkedObservableList(_availableTags, classOf[ServiceTag])

  def containsChanges: Boolean = false
}
