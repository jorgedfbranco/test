package com.leonteq.wrench.ui

import com.leonteq.wrench.model.{EnvironmentId, ServiceId, WrenchService}
import javafx.beans.property.ReadOnlyStringWrapper
import javafx.collections.FXCollections

import scala.collection.JavaConverters._

class MainViewModel(implicit wrenchService: WrenchService) {
  private val _servicesList = FXCollections.observableArrayList(wrenchService.listServices().toArray: _*)
  private var _serviceSelected: Option[ServiceId] = None
  private val _availableEnvironments = FXCollections.observableArrayList[EnvironmentId]()

  private val _workspaces = FXCollections.observableArrayList[WorkspaceViewModel]()
  private val _currentStatus = new ReadOnlyStringWrapper("Wrench started.")

  def selectedService = _serviceSelected
  val availableEnvironments = FXCollections.checkedObservableList(_availableEnvironments, classOf[EnvironmentId])
  val workspaces = FXCollections.checkedObservableList(_workspaces, classOf[WorkspaceViewModel])
  val services = FXCollections.checkedObservableList(_servicesList, classOf[ServiceId])
  def currentStatus = _currentStatus.getReadOnlyProperty

  def selectService(serviceId: ServiceId) = {
    _serviceSelected = Some(serviceId)
    _availableEnvironments.clear()
    _workspaces.clear()

    wrenchService.listEnvironments(serviceId)
      .foreach(_availableEnvironments.add)
  }

  def environmentsContainsChanges(): Boolean =
    _workspaces.asScala.exists(_.containsChanges)

  def onServicesMouseMove() =
    _currentStatus.set("Choose a service to create tags on.")

  def onEnvironmentMouseMove(env: EnvironmentId) =
    _currentStatus.set(
      if (workspaces.asScala.exists(_.environment == env)) {
        s"Close environment workspace and discard changes to ${env.id}."
      } else {
        s"Check out and make changes to ${env.id}."
      }
    )

  def updateWorkspaceVisibility(environmentId: EnvironmentId, visibility: Boolean) = {
    if (visibility) {
      _workspaces.asScala
        .find(_.environment == environmentId)
        .foreach(_workspaces.remove)
    } else {
      if (_workspaces.asScala.exists(_.environment == environmentId))
        sys.error("Workspace already exists.")
      _workspaces.add(new WorkspaceViewModel(environmentId))
      FXCollections.sort(_workspaces, (o1: WorkspaceViewModel, o2: WorkspaceViewModel) =>
        Integer.compare(
          _availableEnvironments.indexOf(o1.environment),
          _availableEnvironments.indexOf(o2.environment)
        ))
    }
  }
}