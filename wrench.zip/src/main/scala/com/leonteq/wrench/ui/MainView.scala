package com.leonteq.wrench.ui

import com.leonteq.wrench.infrastructure.FXMapping._
import com.leonteq.wrench.model.{EnvironmentId, ServiceId}
import javafx.application.Platform
import javafx.beans.binding.Bindings
import javafx.event.ActionEvent
import javafx.geometry.Insets
import javafx.scene.control.Alert.AlertType
import javafx.scene.control._
import javafx.scene.input.MouseEvent
import javafx.scene.layout._
import javafx.util.StringConverter
import org.controlsfx.control.StatusBar
import org.controlsfx.tools.Borders

class MainView(viewModel: MainViewModel) extends VBox {

  private val serviceComboBox = new ComboBox[ServiceId] { self =>
    setPrefWidth(250)
    setItems(viewModel.services)
    setConverter(new StringConverter[ServiceId] {
      override def toString(id: ServiceId): String = if (id == null) null else id.id
      override def fromString(id: String): ServiceId = if (id == null) null else ServiceId(id)
    })
    setOnMouseMoved((_: MouseEvent) => viewModel.onServicesMouseMove)
    setOnAction { (_: ActionEvent) => viewModel.selectService(getSelectionModel.getSelectedItem) }
  }

  private val environmentsBox = new HBox() {
    setSpacing(10)

    val checkboxes = viewModel.availableEnvironments.map((env: EnvironmentId) =>
      new CheckBox(env.id) { cb =>
        override def equals(obj: Any): Boolean = obj match {
          case o:CheckBox => getText == o.getText
          case _ => false
        }

        override def hashCode(): Int =
          getText.hashCode

        setOnAction((_: ActionEvent) => viewModel.updateWorkspaceVisibility(env, !cb.isSelected))
        setOnMouseMoved((_: MouseEvent) => viewModel.onEnvironmentMouseMove(env))
      })
    Bindings.bindContent(getChildren, checkboxes)
  }

  setSpacing(10)

  getChildren.add(new GridPane {
    setPadding(new Insets(10, 10, 0, 10))
    setVgap(10)
    setHgap(10)
    add(new Label("Service:"), 0, 0)
    add(serviceComboBox, 1, 0)
    add(new Label("Environments:"), 0, 1)
    add(environmentsBox, 1, 1)
  })

  private val workspace = new HBox() {
    setPrefHeight(10000)
    val environments = viewModel.workspaces.map(env => new WorkspaceView(env) {
      override def equals(obj: Any): Boolean = obj match {
        case o:WorkspaceView => o.viewModel.environment == viewModel.environment
        case _ => false
      }
      override def hashCode(): Int = viewModel.environment.hashCode()
    })
    Bindings.bindContent(getChildren, environments)
  }

  private val workspaceBorder =
    Borders
      .wrap(workspace)
      .lineBorder()
      .outerPadding(5, 10, 0, 10)
      .title("Workspaces")
      .buildAll()

  getChildren.add(workspaceBorder)

  val statusbar = new StatusBar()
  statusbar.setPrefHeight(70)
  statusbar.textProperty().bind(viewModel.currentStatus)
  getChildren.add(statusbar)
}