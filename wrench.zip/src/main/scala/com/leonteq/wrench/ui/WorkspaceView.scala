package com.leonteq.wrench.ui

import com.leonteq.wrench.model.ServiceTag
import javafx.geometry.Pos
import javafx.scene.control._
import javafx.scene.layout.{GridPane, HBox, VBox}
import org.controlsfx.tools.Borders

case class WorkspaceView(viewModel: WorkspaceViewModel) extends VBox {
  val grid = new GridPane {
    setPrefWidth(100000)
    setPrefHeight(10000)
    setHgap(10)
    setVgap(10)

    add(new Label("Tag:"), 0, 0)
    private val tagComboBox = new ComboBox[ServiceTag]() {
      setPrefWidth(250)
    }
    add(tagComboBox, 1, 0)

    add(new Label("New version:"), 0, 1)
    private val newVersionText = new TextField()
    add(newVersionText, 1, 1)

    private val treeView = new TreeView[String]() {
      setPrefHeight(10000)
      setPrefWidth(10000)
    }
    add(treeView, 0, 2, 2, 1)
    add(new HBox { hbox =>
      setAlignment(Pos.CENTER_RIGHT)
      setSpacing(10)
      hbox.getChildren.add(new Button("Clear changes"))
      hbox.getChildren.add(new Button("Push changes"))
    }, 0, 3, 2, 1)
  }
  getChildren.add(Borders
    .wrap(grid)
    .lineBorder()
    .outerPadding(0)
    .innerPadding(10)
    .title(viewModel.environment.id)
    .buildAll()
  )
}